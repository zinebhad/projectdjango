# views.py
from django.contrib import messages
from django.contrib.auth import authenticate, login, logout as auth_logout, update_session_auth_hash
from django.contrib.auth.decorators import login_required
from django.shortcuts import render, redirect
from .forms import RegisterForm
from .models import Profile
from django.http import HttpResponse, HttpResponseRedirect

# Create your views here.
def register(request):
    if request.method == 'POST':
        user_form = RegisterForm(request.POST,request.FILES) # request.user is user  data
        if user_form.is_valid():
            user_form.save()
            username = user_form.cleaned_data.get('username')
            password = user_form.cleaned_data.get('password1')
            user = authenticate(username=username, password=password)
            login(request, user)
            current_user = request.user
            phone = user_form.cleaned_data.get('phone')
            address = user_form.cleaned_data.get('address')
            city = user_form.cleaned_data.get('city')
            country = user_form.cleaned_data.get('country')
            image = user_form.cleaned_data.get('image')
            data=Profile()
            data.user_id=current_user.id
            data.phone=phone
            data.address=address
            data.city=city
            data.country=country
            data.image=image
            data.save()
            messages.success(request, 'Your account has been updated!')
            return HttpResponseRedirect('/')
    else:
        user_form = RegisterForm()
         #"userprofile" model -> OneToOneField relatinon with user
        context = {
            'user_form': user_form,
        }
        return render(request, 'register/register.html', context)
def logout(request):
    auth_logout(request)
    return redirect('/')



@login_required(login_url='/login') # Check login
def index(request):
    #category = Category.objects.all()
    current_user = request.user  # Access User Session information
    profile = Profile.objects.get(user_id=current_user.id)
    context = {#'category': category,
               'profile':profile}
    return render(request,'user_profile.html',context)