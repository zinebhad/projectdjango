from django.contrib.auth.models import User
from django.db import models



   
class Profile(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    phone = models.CharField(blank=True, max_length=20,null=True)
    address = models.CharField(blank=True, max_length=150,null=True)
    city = models.CharField(blank=True, max_length=20,null=True)
    country = models.CharField(blank=True, max_length=50,null=True)
    image = models.ImageField(blank=True, upload_to='media',null=True)



