from django.shortcuts import render
from django.contrib import messages
from django.http import HttpResponse, HttpResponseRedirect
from .models import Restaurants,ImageDetails,Comment,CommentForm,ContactMessage,ContactForm,Dishs
from RegLog.models import Profile
from geopy import Nominatim
from django.views import generic
import folium

# Create your views here.

def detail(request,id):
	rest=Restaurants.objects.get(id=id)
	current_user = request.user
	context={'images':ImageDetails.objects.all(),'rest':rest,'comments':Comment.objects.filter(restaurant_id=id),'dishs':Dishs.objects.filter(rest_id=id)
}
	return render(request,'restaurants/detail.html',context)

def restaurants_list(request):
    geolocator = Nominatim(user_agent="Restaurants")
    m=folium.Map(width=500,height=500,location=[40,-99],zoom_start=4)
    restList=Restaurants.objects.all()
    query=request.GET.get("p")
    if query:
        restList=restList.filter(Type=query)
    current_user=request.user
    context={'m':m,'restaurants':restList,'fast':Restaurants.objects.filter(Type=2),'coffe':Restaurants.objects.filter(Type=3),'comments':Comment.objects.all(),'add':Profile.objects.filter(user_id=current_user.id)}
    return render(request, 'restaurants/index.html', context)

def home(response):
   context={}
   geolocator = Nominatim(user_agent="Restaurants")
   test=Restaurants.objects.all()
   m = folium.Map(width=500,height=500,location=[40, -99], zoom_start=4)
   context={'m':m,'test':test}
          
   return render(response,"restaurants/showMap.html",context)


def addcomment(request,id):
   url = request.META.get('HTTP_REFERER')  # get last url
   #return HttpResponse(url)
   if request.method == 'POST':  # check post
      form = CommentForm(request.POST)
      if form.is_valid():
         data = Comment()  # create relation with model
         data.comment = form.cleaned_data['comment']
         data.rate = form.cleaned_data['rate']
         data.ip = request.META.get('REMOTE_ADDR')
         data.restaurant_id=id
         current_user= request.user
         data.user_id=current_user.id
         data.save()  # save data to table
         messages.success(request, "Your review has ben sent. Thank you for your interest.")
         return HttpResponseRedirect(url)

   return HttpResponseRedirect(url)

def contactus(request):
    if request.method == 'POST': # check post
        form = ContactForm(request.POST)
        if form.is_valid():
            data = ContactMessage() #create relation with model
            data.name = form.cleaned_data['name'] # get form input data
            data.email = form.cleaned_data['email']
            data.subject = form.cleaned_data['subject']
            data.message = form.cleaned_data['message']
            data.ip = request.META.get('REMOTE_ADDR')
            data.save()  #save data to table
            messages.success(request,"Your message has ben sent. Thank you for your message.")
            return HttpResponseRedirect('/contact')
    form = ContactForm
    context={'form':form }
    return render(request, 'restaurants/contactus.html', context)


